require('dotenv').config();

module.exports = {
  VIRUSTOTAL_API_KEY: process.env.VIRUSTOTAL_API_KEY
};
